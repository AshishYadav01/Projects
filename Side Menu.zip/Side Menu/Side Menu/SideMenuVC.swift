//
//  SideMenuViewController.swift
//  Side Menu
//
//  Created by Ashish on 23/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import UIKit

class SideMenuVC: UIViewController {
    
    let SideMenuLabelArray = ["Home" , "Setting", "Terms and Conditions", "Privacy policy", "Logout"]
    
//    MARK: Outlets
//    ==================
    @IBOutlet weak var sideMenuTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.sideMenuTableView.dataSource = self
        self.sideMenuTableView.delegate = self
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}


//MARK: UITableViewDelegate & DataSource Methods
//================================================
extension SideMenuVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        return SideMenuLabelArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "SideMenuCellID", for: indexPath) as? SideMenuCell else{
            
            fatalError("Cell Not Found !")
        }
        
        cell.cellLabel.text = SideMenuLabelArray[indexPath.row]
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        
        guard let parentVC = self.parent as? MainVC else{return}
        
        parentVC.title = SideMenuLabelArray[indexPath.row]
        
        switch indexPath.row {
            
        case 0: parentVC.addContentView(storyboard.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC)
            
            
        case 1 : parentVC.addContentView(storyboard.instantiateViewController(withIdentifier: "SettingVC") as! SettingVC)
            
        case 2: parentVC.addContentView(storyboard.instantiateViewController(withIdentifier: "TermsAndConditionVC") as! TermsAndConditionVC)
            
        case 3: parentVC.addContentView(storyboard.instantiateViewController(withIdentifier: "PrivacyPolicyVC") as! PrivacyPolicyVC)
            
        case 4 : parentVC.addContentView(storyboard.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC)
            
        default : break
            
        }
    }
}

//MARK: sideMenuTableViewCell Class
//===================================
class SideMenuCell : UITableViewCell {
    
    @IBOutlet weak var cellLabel: UILabel!
    
}
