//
//  ViewController.swift
//  Side Menu
//
//  Created by Ashish on 23/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import UIKit

class MainVC: UIViewController {

//    MARK: Variable
//    ================
    var addSubView : UIViewController! = nil
    var HomeSubView : UIViewController! = nil
    
//    MARK: Outlets
//    ==============
    @IBOutlet weak var menuBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()


    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
//        MARK: Add HOMEVC into MAINVC
//        ==============================
        
        self.HomeSubView = self.storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
        
        HomeSubView?.view.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        HomeSubView?.view.frame.origin = CGPoint(x: 0 , y: 65)
        self.addChildViewController(HomeSubView!)
        self.view.addSubview((HomeSubView?.view)!)
        addSideMenu()
        
    }
    
//    MARK: Button Actions
//    ========================
    @IBAction func sideMenuBtn(_ sender: UIButton) {
        
        sender.isSelected = !sender.isSelected
        
        if sender.isSelected {
            
            UIView.animate(withDuration: 0.5, animations: {
                
                self.addSubView.view.frame.origin = CGPoint(x: 0 , y: 65)
                
            })
            
        } else {
            
            UIView.animate(withDuration: 0.5, animations: {
                
                self.addSubView.view.frame.origin = CGPoint(x: -self.view.frame.width / 2, y: 65)
            })
        }
    }
    
//    MARK: Method to add SideMenu
//    =================================
    func addSideMenu(){
        
        self.addSubView = self.storyboard?.instantiateViewController(withIdentifier: "SideMenuVC") as! SideMenuVC
        
        addSubView?.view.frame = CGRect(x: 0, y: 0, width: self.view.frame.width / 2, height: self.view.frame.height)
        addSubView?.view.frame.origin = CGPoint(x: -self.view.frame.width / 2 , y: 65)
        self.addChildViewController(addSubView!)
        self.view.addSubview((addSubView?.view)!)
        
    }
    
//    MARK: Method to add contentView
//    =================================
    func addContentView(_ subViewController : UIViewController){
        
        addSubView.removeFromParentViewController()
        HomeSubView.removeFromParentViewController()
        subViewController.title = "yuosdiuas"
        subViewController.removeFromParentViewController()
        subViewController.view.frame = CGRect(x: 0, y: 0, width: self.view.frame.width , height: self.view.frame.height)
        subViewController.view.frame.origin = CGPoint(x: 0 , y: 65)
        self.addChildViewController(subViewController)
        self.view.addSubview((subViewController.view)!)
        
        self.menuBtn.isSelected = false
        addSideMenu()
        
    }
}

