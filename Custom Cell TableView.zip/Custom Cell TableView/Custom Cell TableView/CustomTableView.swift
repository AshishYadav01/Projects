//
//  CustomTableView.swift
//  Custom Cell TableView
//
//  Created by Ashish on 09/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import UIKit

class CustomTableView: UIViewController {

//    MARK: Outlets
    
    @IBOutlet weak var CustomTableViewOult: UITableView!
    
    @IBOutlet weak var tableViewBottomConstraint: NSLayoutConstraint!
    
//    MARK: Constant and Variables
    
    var dic : [[String: Any]] = [
        
        ["label1": "FullName" , "Data" : "Ashish Yadav"],
        ["label1" : "Email" , "Data" : "Ashish@gmail.com"],
        ["label1": "Birth Date" , "Data" : "february 12 1992"],
        ["label1": "Height" , "Data" : "5'11\""],
        ["label1": "Weight" , "Data" : "70 lbs"],
        ["label1": "Gender" , "Data" : "Male"],
        ["label1": "Blood" , "Data" : "B+"]
    ]
    
//    MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.CustomTableViewOult.delegate = self
        self.CustomTableViewOult.dataSource = self
        
        print("Call in ViewDidLoad")
        let nib = UINib(nibName: "TableViewCell", bundle: nil)
        CustomTableViewOult.register(nib, forCellReuseIdentifier: "UserdetailsCellID")
        
        print("Call after nib")
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyBoardWillApear), name: .UIKeyboardDidShow, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyBoardDisappear), name: .UIKeyboardDidHide, object: nil)
//        NotificationCenter.default.addObserver(forName: <#T##NSNotification.Name?#>, object: <#T##Any?#>, queue: <#T##OperationQueue?#>, using: <#T##(Notification) -> Void#>)
        

        
        
    }
    
    func keyBoardWillApear(notification: NSNotification){
        
        guard let keyboardSize = notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue else { return }
        self.tableViewBottomConstraint.constant = keyboardSize.cgRectValue.height
        
    }
    
    func keyBoardDisappear(notification : NSNotification) {
        
        self.tableViewBottomConstraint.constant = 0
        
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func viewWillAppear(animated: Bool){
        super.viewWillAppear(animated)
        
        
    }


//    MARK: IBOutlet Actions
    
    
//    MARK:  Private Methods
    
    
}

//MARK:  TableViewDelegates, TableViewDatasource

extension CustomTableView : UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.dic.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
     let cell = tableView.dequeueReusableCell(withIdentifier: "UserdetailsCellID", for: indexPath) as! UserdetailsCell
        
        cell.setData(data: dic[indexPath.row] as! [String : String])
     
        cell.textFieldOutlet.delegate = self
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 59
    }
    
    
}

extension UIView {
    
    func acessIndex(textField : UITextField) -> IndexPath?{
    
        guard let cell : Any = textField.superview?.superview as? UITableViewCell
            else {return nil}
        guard let tableView : Any = (cell as AnyObject).superview as? UITableView
            else {return nil}
        guard let index : Any = (tableView as AnyObject).indexPath
            else{return nil}
        return index as? IndexPath
    
    }
    
}

extension CustomTableView : UITextFieldDelegate {
    
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
//        
//        
//    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
    
     
     return true
    }
}
