
import UIKit

class UserdetailsCell: UITableViewCell {

//    MARK:Outlets
    
    @IBOutlet weak var labelOutlet: UILabel!
    
    @IBOutlet weak var textFieldOutlet: UITextField!
    
    @IBOutlet weak var sepratorOutlet: UIView!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setData(data : [String: String]) {
        
        labelOutlet.text = data["label1"]
        textFieldOutlet.text = data["Data"]
        
    }
    
}

extension UserdetailsCell : UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
//        let indexVal = acessIndex(textFieldOutlet)
        
        
        
       return true
    }
    
}
