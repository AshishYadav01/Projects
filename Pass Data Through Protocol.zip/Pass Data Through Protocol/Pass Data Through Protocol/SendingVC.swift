//
//  SendingVC.swift
//  Pass Data Through Protocol
//
//  Created by Ashish on 08/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import UIKit

protocol DataSentDelegate {
    
    func pass(data : String)
}

class SendingVC: UIViewController {

    @IBOutlet weak var textField: UITextField!
    
    var delegate : DataSentDelegate? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func sendBtnActn(_ sender: UIButton) {
    
        if delegate != nil {
            
            if !(textField.text?.isEmpty)! {
                
                let data = self.textField.text
                
                delegate?.pass(data: data!)
                
                navigationController?.popViewController(animated: true)
                
            }
        }
        
    
    }
    

    }
