

import UIKit

class RecevingVC: UIViewController, DataSentDelegate  {

    @IBOutlet weak var labelOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func viewWillAppear(_ animated: Bool) {
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func pass(data: String) {
        
        self.labelOutlet.text = data
        
    }

    @IBAction func nextScreen(_ sender: UIButton) {
        
        let nextScene = storyboard?.instantiateViewController(withIdentifier: "SendingVC") as! SendingVC
        
        navigationController?.pushViewController(nextScene, animated: true)
        
        nextScene.delegate = self
        
        self.labelOutlet.text? = ""
        
    }

}

