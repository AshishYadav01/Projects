//
//  OwnerAndBuyer.swift
//  Protocol
//
//  Created by Ashish on 03/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import Foundation

protocol projectAvaliability{
    
    func isProjectAvailiable()
    
    func isPCavailiable()
}

class ProjectManager : projectAvaliability{
    
    var officeEmployee : Employee?
    
    func isPCavailiable() {
        
        print("ProjectManager: Yes, PC is availiable")
    }

    
    func isProjectAvailiable() {
        
        print("ProjectManager: No Project is not avaliable")
    }
    
}

class TeamLead: projectAvaliability{
    
    func isPCavailiable() {
        
        print(" TeamLead : No PC is not vaialiable")
        
    }

    
    func isProjectAvailiable() {
        
        print(" TeamLead : Yes Project is avaliable")
    
    }
}

class Employee{
    
    var delegate : projectAvaliability? = nil
    
    func enquireProject(){
        
        self.delegate?.isProjectAvailiable()
        
    }
    
    func enquirePC(){
        
        self.delegate?.isPCavailiable()
        
    }
}
