//
//  ViewController.swift
//  Search Images
//
//  Created by Ashish on 22/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import UIKit
import AlamofireImage

class SearchImagesVC: UIViewController {
    
//    MARK: Constants and Variables
    
    var searchText : String! = ""
    var searchImagesList = [ImageModel]()
    
//    MARK: Outlets
    
    @IBOutlet weak var searchBar: UISearchBar!

    @IBOutlet weak var searcResultTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.searchBar.delegate = self
        self.searcResultTableView.dataSource = self
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//    MARK: Service Hit Method
    func searchEntereddata (){
        
        Webservices().fetchDataFromPixabay(withQuery: self.searchText!, success: { (images : [ImageModel]) in
            
            self.searchImagesList = images
            self.searcResultTableView.reloadData()
            
        }) { (error : Error) in
            
            print(error)
        }
    }
}

//MARK: UITableView Deleagte and Datasource Methods
extension SearchImagesVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return searchImagesList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "SearchImageCellID", for: indexPath) as? SearchImageCell else {
            
            fatalError("Cell is not Found")
        }
        
        if let url = URL(string: searchImagesList[indexPath.row].previewURL) {
            
            print(url)
            
            cell.searchImage.af_setImage(withURL : url)
        }
        
        cell.searchImage.contentMode = .scaleAspectFill
        
        return cell
    }
}

//Mark: TableViewCell Class
class SearchImageCell : UITableViewCell {
    
     @IBOutlet weak var searchImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}

//MARK: SearchBar delegate Methods
extension SearchImagesVC : UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar){
    
        if !(searchBar.text!.isEmpty) {
          self.searchText = self.searchBar.text
            
            searchEntereddata()
        }
    }
}
