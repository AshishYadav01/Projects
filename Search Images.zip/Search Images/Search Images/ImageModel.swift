

import Foundation
import SwiftyJSON

//MARK: Image Model of One Object in JSON

struct ImageModel {
    
    let id : String!
    
    var comments = 0
    var downloads = 0
    
    var favorites = 0
    var likes = 0
    var views = 0
    
    var pageURL : String = ""
    var userImageURL : String = ""
    var webformatURL : String = ""
    var previewURL : String = ""
    
    init(withJSON json: JSON) {
        
        self.id = json["id"].stringValue
        self.comments = json["comments"].intValue
        
        self.downloads = json["downloads"].intValue
        self.favorites = json["favorites"].intValue
        self.likes = json["likes"].intValue
        self.views = json["views"].intValue
        
        self.pageURL = json["pageURL"].stringValue
        self.userImageURL = json["userImageURL"].stringValue
        self.webformatURL = json["webformatURL"].stringValue
        self.previewURL = json["previewURL"].stringValue
        
    }
    
}
