//
//  ExploreVC.swift
//  Collection View
//
//  Created by Ashish on 10/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import UIKit

class ExploreVC: UIViewController {

//    MARK: Outlet
    
    @IBOutlet weak var tableViewContainCollectionView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tableViewContainCollectionView.dataSource = self
        self.tableViewContainCollectionView.delegate = self
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

//MARK: TableView Delegate & DataSource

extension ExploreVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewContainCollectionViewCellID", for: indexPath) as? TableViewContainCollectionViewCell
            
        else { fatalError("Cell Not Found !")
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 667
    }
    
}

class TableViewContainCollectionViewCell : UITableViewCell {
    
    @IBOutlet weak var tableViewCollectionView: UICollectionView!
    
    override func awakeFromNib() {
        
            super.awakeFromNib()
        
        self.tableViewCollectionView.layer.backgroundColor = UIColor.blue.cgColor
        self.tableViewCollectionView.dataSource = self
        self.tableViewCollectionView.delegate = self
        
    }
    
}

extension TableViewContainCollectionViewCell : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
//    MARK: UICollectionViewDelegateFlowLayout:-- Methods
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        
        return CGSize(width: 70, height: 70)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        return UIEdgeInsets(top: 10, left: 10, bottom: -2, right: 7)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        
        return CGSize(width: 0, height: 0)
    }
    
//    MARK: UICollectionViewDelegate:-- Methods
    
//    MARK: UICollectionViewDataSource:-- Method
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        guard let item = collectionView.dequeueReusableCell(withReuseIdentifier: "tableViewCollectionViewCellID", for: indexPath) as? tableViewCollectionViewCell
            else {
            fatalError("Fatal Error !")
        }
        
       return item
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 2
    }
    
}

class tableViewCollectionViewCell : UICollectionViewCell {
    
    
    
}
