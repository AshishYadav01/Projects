
import UIKit

class CollectionViewVC: UIViewController {

    var userName : [[String : Any]] = [
    
        ["userName" : "Ashish" , "favColor" : UIColor.black],
        ["userName" : "Amit" , "favColor" : UIColor.red],
        ["userName" : "Shubham" , "favColor" : UIColor.white],
        ["userName" : "Naveen" , "favColor" : UIColor.blue],
        ["userName" : "Ravi" , "favColor" : UIColor.cyan],
        ["userName" : "Yogesh" , "favColor" : UIColor.brown],
        ["userName" : "Ahmad" , "favColor" : UIColor.darkGray],
        ["userName" : "Yadvindra" , "favColor" : UIColor.green],
        ["userName" : "Avinash" , "favColor" : UIColor.orange],
        ["userName" : "Ambrish" , "favColor" : UIColor.purple],
        ["userName" : "Nitesh" , "favColor" : UIColor.yellow],
        ["userName" : "Shivam" , "favColor" : UIColor.black],
        ["userName" : "Rahul" , "favColor" : UIColor.red],
        ["userName" : "Mohit" , "favColor" : UIColor.blue],
        ["userName" : "Sanju" , "favColor" : UIColor.cyan],
        ["userName" : "Himanshu" , "favColor" : UIColor.green],
        ["userName" : "Sangeet" , "favColor" : UIColor.purple],
        ["userName" : "Vikash" , "favColor" : UIColor.yellow],
        ["userName" : "Vinod" , "favColor" : UIColor.darkGray],
        ["userName" : "Nitin" , "favColor" : UIColor.black]
    
    ]
    
    let screenSize = UIScreen.main.bounds.size
    
    
//    MARK: Outlet
    
    @IBOutlet weak var imageCollectionView: UICollectionView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       imageCollectionView.dataSource = self
       imageCollectionView.delegate = self
       
//        let collectionLayout = UICollectionViewFlowLayout()
//        collectionLayout.itemSize = CGSize(width: 150, height: 150)
//        collectionLayout.minimumInteritemSpacing = 10
//        collectionLayout.minimumLineSpacing = 10
//        collectionLayout.scrollDirection = .vertical
//        
//        imageCollectionView.collectionViewLayout = collectionLayout
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}



extension CollectionViewVC : UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return self.userName.count
    }
    
    // The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCellID", for: indexPath) as? CollectionViewCell else{
        
            fatalError("Cell Not Found !")
            
        }
        
        let users = UserInfo(withJSON: userName[indexPath.item])
        
        cell.populateTheData(users)
        
        print("cellframe: \(cell.viewOnCell.frame)")
        
        return cell
    }
    
//    MARK: UICollectionViewDelegateFlowLayout Methods

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
     
        
        return CGSize(width: 30, height: 30)
    }

    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = (self.screenSize.width - 30) / 3
        
        return CGSize(width: width, height: width+25.0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        return UIEdgeInsets(top: 0.0, left: 5.0, bottom: 0.0, right: 5.0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        return 10.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        
        return 0
    }

}

class UserInfo {
    
    var userName : String
    var favColor : UIColor
    
    init(withJSON data: [String : Any]) {
        
        self.userName = data["userName"] as! String
        self.favColor = data["favColor"] as! UIColor
        
    }
    
}

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var viewOnCell: UIView!
    @IBOutlet weak var labelOnCell: UILabel!
    
    
    func populateTheData(_ user : UserInfo){
        
        labelOnCell.text = user.userName
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.contentView.backgroundColor = UIColor.cyan
        viewOnCell.backgroundColor = UIColor.red
        
//        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+0.1) {
//            self.makeCornerRound()
//        }
//    }
//    
//    func makeCornerRound() {
//        viewOnCell.layer.cornerRadius = viewOnCell.layer.frame.height / 2
//        viewOnCell.layer.masksToBounds = true
//    }
    
}
}


