//
//  GridView.swift
//  ListToGridView
//
//  Created by Ashish on 13/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import UIKit

public class CarModelForGridView{
    
    var carName : String
    var carImage : String
    
    init(withJSON data : [String : Any]) {
        
        carName = data["CarName"] as! String

        carImage = data["CarImage"] as! String
    }
    
}

class GridView: UICollectionViewCell {
    
    @IBOutlet weak var carImage: UIImageView!
    @IBOutlet weak var carName: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code

    }
    
    func populateCarDataInGridView(_ car : CarModelForGridView)  {
        
        let carImage1 = car.carImage
        
        self.carImage.backgroundColor = UIColor(patternImage: UIImage(named: carImage1)!)
        
        carName.text = car.carName
        
        
    }

}


