
import UIKit

enum ListToGridSelection {
    case isListView
    case isGridView
}

class ListToGridViewVC: UIViewController {
    
    //    MARK: Constant and Vaiables
    
    var car : [[String : Any]] = [
        
        ["CarName" : "BMW",              "CarImage" : "black-bmw"],
        ["CarName" : "Chevrolet Camaro", "CarImage" : "chevrolet_camaro"],
        ["CarName" : "GT Audi",          "CarImage" : "gt_audi"],
        ["CarName" : "Red Mclaren",      "CarImage" : "red-mclaren"],
        ["CarName" : "BMW",              "CarImage" : "black-bmw"],
        ["CarName" : "Chevrolet Camaro", "CarImage" : "chevrolet_camaro"],
        ["CarName" : "GT Audi",          "CarImage" : "gt_audi"],
        ["CarName" : "Red Mclaren",      "CarImage" : "red-mclaren"],
        ["CarName" : "BMW",              "CarImage" : "black-bmw"],
        ["CarName" : "Chevrolet Camaro", "CarImage" : "chevrolet_camaro"],
        ["CarName" : "GT Audi",          "CarImage" : "gt_audi"],
        ["CarName" : "Red Mclaren",      "CarImage" : "red-mclaren"],
        ["CarName" : "BMW",              "CarImage" : "black-bmw"],
        ["CarName" : "Chevrolet Camaro", "CarImage" : "chevrolet_camaro"],
        ["CarName" : "GT Audi",          "CarImage" : "gt_audi"],
        ["CarName" : "Red Mclaren",      "CarImage" : "red-mclaren"],
        ["CarName" : "BMW",              "CarImage" : "black-bmw"],
        ["CarName" : "Chevrolet Camaro", "CarImage" : "chevrolet_camaro"],
        ["CarName" : "GT Audi",          "CarImage" : "gt_audi"],
        ["CarName" : "Red Mclaren",      "CarImage" : "red-mclaren"]
        
    ]
    
    var selection = ListToGridSelection.isListView
    let listLayout = ListViewFlowLayout()
    let gridLayout = GridViewFlowLayout()
    
    var containCellIndex = [IndexPath]()
    
    //    Mark: Outlets
    
    @IBOutlet weak var listToGridCollectionViewOutlet: UICollectionView!
    
    @IBOutlet weak var converterBtnOutlet: UIButton!
    
    @IBOutlet weak var deleteBtnoutlt: UIButton!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        //    MARK: Register Nib
        
        let GridNib = UINib(nibName: "GridView", bundle: nil)
        
        listToGridCollectionViewOutlet.register(GridNib, forCellWithReuseIdentifier: "GridViewID")
        
        let listNib = UINib(nibName: "ListView", bundle: nil)
        
        listToGridCollectionViewOutlet.register(listNib, forCellWithReuseIdentifier: "ListViewID")
        
        self.listToGridCollectionViewOutlet.dataSource = self
        self.listToGridCollectionViewOutlet.delegate = self
        
        
        let tapGesture = UILongPressGestureRecognizer(target: self, action: #selector(self.longPressedOnCell))
        
        tapGesture.delegate = self
        
        listToGridCollectionViewOutlet.addGestureRecognizer(tapGesture)
        
        
        self.listToGridCollectionViewOutlet.reloadData()
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.converterBtnOutlet.layer.borderWidth = 2.0
        self.converterBtnOutlet.layer.borderColor = UIColor.white.cgColor
        
        self.deleteBtnoutlt.layer.borderWidth = 2.0
        self.deleteBtnoutlt.layer.borderColor = UIColor.white.cgColor
        self.deleteBtnoutlt.isHidden = true
        self.listToGridCollectionViewOutlet.reloadData()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //    MARK: Button Actions
    
    @IBAction func carListToGridViewBtnActn(_ sender: UIButton) {
        
        self.listToGridCollectionViewOutlet.reloadData()
        
        switch selection {
        case .isListView:
            
            UIView.animate(withDuration: 0.8, animations: {
                self.selection = .isGridView
                
                self.listToGridCollectionViewOutlet.collectionViewLayout.invalidateLayout()
                self.listToGridCollectionViewOutlet.setCollectionViewLayout(self.gridLayout, animated: true)
                
                self.converterBtnOutlet.isEnabled = false
                }, completion: { (true) in
                    
                    self.view.layoutIfNeeded()
                    self.converterBtnOutlet.isEnabled = true
            })
        case .isGridView:
            UIView.animate(withDuration: 0.8, animations: {
                self.selection = .isListView
                self.listToGridCollectionViewOutlet.collectionViewLayout.invalidateLayout()
                self.listToGridCollectionViewOutlet.setCollectionViewLayout(self.listLayout , animated: true)
                self.converterBtnOutlet.isEnabled = false
                }, completion: { (true) in
                    self.view.layoutIfNeeded()
                    self.converterBtnOutlet.isEnabled = true
            })
        }
    }
    
    @IBAction func deleteBtnActn(_ sender: UIButton) {
        
        for indexPath in containCellIndex.sorted(by: >){
            car.remove(at: indexPath.item)
        }
        
        self.containCellIndex.removeAll()
        deleteBtnoutlt.isHidden = true
        self.listToGridCollectionViewOutlet.reloadData()
        
    }
}

//MARK: UICollectionView Delegate,DataSource, DelegateFlowlayout Methods

extension ListToGridViewVC :  UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, UICollectionViewDelegate {
    
    //    MARK: UICollectionViewDelegateFlowLayout Methods
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        return UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
    }
    
    //    MARK:  UICollectionViewDataSource Methods
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return car.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let carView = CarModelForGridView(withJSON: car[indexPath.item])
        
        self.deleteBtnoutlt.isHidden = false
        self.listToGridCollectionViewOutlet.collectionViewLayout.invalidateLayout()
        
        switch selection {
            
        case .isListView:
            
            guard let listCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ListViewID", for: indexPath) as? ListView else { fatalError("ListView Cell Not Found !")}
            
            listCell.populateCarDataInListView(carView)
            
            
            print(containCellIndex)
            
            if self.containCellIndex.contains(indexPath) {
                
                listCell.backgroundColor = UIColor.gray
                self.deleteBtnoutlt.isHidden = false
                
            }
            else if self.containCellIndex.isEmpty{
                
                listCell.backgroundColor = UIColor.white
                self.deleteBtnoutlt.isHidden = true
            }
            else{
                
                listCell.backgroundColor = UIColor.white
                self.deleteBtnoutlt.isHidden = false
            }
            return listCell
            
        case .isGridView :
            
            guard let gridCell = collectionView.dequeueReusableCell(withReuseIdentifier: "GridViewID", for: indexPath) as? GridView
                else { fatalError("GridView Cell Not Found !")}
            gridCell.populateCarDataInGridView(carView)
            
            if self.containCellIndex.contains(indexPath) {
                
                gridCell.backgroundColor = UIColor.gray
                self.deleteBtnoutlt.isHidden = false
            }
            else if self.containCellIndex.isEmpty {
                gridCell.backgroundColor = UIColor.white
                self.deleteBtnoutlt.isHidden = true
            }
                
            else{
                gridCell.backgroundColor = UIColor.white
                self.deleteBtnoutlt.isHidden = false
            }
            
            return gridCell
        }
    }
    
}

//MARK:  UIGestureRecognizerDelegate

extension ListToGridViewVC: UIGestureRecognizerDelegate {
    
    func longPressedOnCell(gesture: UILongPressGestureRecognizer) {
        
        if gesture.state == .ended {
            
            return
        }
        
        let pressPoint = gesture.location(in : self.listToGridCollectionViewOutlet)
        let indexPath = self.listToGridCollectionViewOutlet.indexPathForItem(at: pressPoint)
        let cell = self.listToGridCollectionViewOutlet.cellForItem(at: indexPath!)
        print("before filter\(containCellIndex)")
        cell?.isSelected = true
        if self.containCellIndex.contains(indexPath!){
            
            let filter = self.containCellIndex.filter({$0 != indexPath})
            self.containCellIndex = filter
            cell?.isSelected = false
            
        }
        else {
            containCellIndex.append(indexPath!)
        }
        self.listToGridCollectionViewOutlet.reloadData()
    }
}



