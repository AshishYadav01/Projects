//
//  CollectionReusableView.swift
//  ListToGridView
//
//  Created by Ashish on 13/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import UIKit

class CollectionReusableView: UICollectionReusableView {
        
}
