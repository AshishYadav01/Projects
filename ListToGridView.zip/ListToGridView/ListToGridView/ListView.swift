
import UIKit


class ListView: UICollectionViewCell {
    
    @IBOutlet weak var carImage: UIImageView!
    @IBOutlet weak var carName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func populateCarDataInListView(_ car : CarModelForGridView) {
        
        let carImage1 = car.carImage
        self.carImage.backgroundColor = UIColor(patternImage: UIImage(named: carImage1)!)
        carName.text = car.carName
    }
    
    override func layoutSubviews() {
        
        super.layoutSubviews()
        
//        self.frame.size.width = UIScreen.main.bounds.width
        
        
    }
}
