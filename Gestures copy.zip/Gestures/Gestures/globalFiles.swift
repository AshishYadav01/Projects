//
//  globalFiles.swift
//  Gestures
//
//  Created by Ashish on 18/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import Foundation
import UIKit


extension UIView {
    
//    func randomColorChange(gesture: UITapGestureRecognizer){
//        
//        let randomRed:CGFloat = CGFloat(drand48())
//        
//        let randomGreen:CGFloat = CGFloat(drand48())
//        
//        let randomBlue:CGFloat = CGFloat(drand48())
//        
//        gesture.view?.backgroundColor = UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: 1.0)
//    }

}


