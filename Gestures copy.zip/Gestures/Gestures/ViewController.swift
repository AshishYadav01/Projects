//
//  ViewController.swift
//  Gestures
//
//  Created by Ashish on 17/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var gestureView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(draggTheView(gesture:)))
        
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(randomColorChange(gesture:)))
        
        
//        gestureView.addGestureRecognizer(tapGesture)
        gestureView.addGestureRecognizer(panGesture)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func randomColorChange(gesture : UITapGestureRecognizer) {
        
            let randomRed:CGFloat = CGFloat(drand48())
            
            let randomGreen:CGFloat = CGFloat(drand48())
            
            let randomBlue:CGFloat = CGFloat(drand48())
    
             gesture.view?.backgroundColor = UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: 1.0)
    }
    
    func draggTheView(gesture : UIPanGestureRecognizer) {
        
        
        switch gesture.state {
        case .began: gesture.minimumNumberOfTouches = 1
        case .cancelled: break
        
        case .changed: let addX = gesture.translation(in: self.view)
        
        
            gesture.view?.center = CGPoint(x: (gesture.view?.center.x)! + addX.x, y: (gesture.view?.center.y)! + addX.y)
            
            print("gestureCentre : \(gesture.view?.center)")
            gesture.setTranslation(CGPoint.zero, in: self.view)
            
        case .failed : break
            
        case .possible : gesture.view?.center = CGPoint(x: 0, y: 0)
        
        default: break
        }
        
        
//        let viewX = gesture.view?.frame.origin.x
//        let viewY = gesture.view?.frame.origin.y
//        let width = gesture.view?.frame.width
//        let height = gesture.view?.frame.height
//        var lastLocation = gestureView.superview?.center
//        
//        var trans = gesture.translation(in: gestureView)
//        
//        gesture.view?.frame = CGRect(x: (lastLocation?.x)! + trans.x, y: (lastLocation?.y)! + trans.y, width: width!, height: height!)
    
    }
}

